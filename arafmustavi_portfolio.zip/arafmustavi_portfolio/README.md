# Araf Mustavi — AI-Powered Portfolio (Flask)

A production-ready personal portfolio with:
- Modern responsive Flask website (dark galaxy theme + Tailwind)
- Floating WhatsApp button with pre-filled greeting
- **AI chat assistant** grounded in Araf's docs via RAG
- Automatic **WhatsApp escalation** when the AI isn't confident
- Admin dashboard (auth, uploads, projects, chat logs, reindex)
- Pluggable LLM providers (OpenAI · Anthropic · Gemini · Ollama · Mock)

---

## 🚀 Quick Start

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # edit as needed
python seed.py
python run.py
```

Visit **http://localhost:5000**. Admin: **/admin/login** (default `araf` / `changeme` — change immediately).

The app runs out-of-the-box with **no API keys** using the built-in `MockLLMProvider`.

---

## 🔑 Environment Variables

| Var | Purpose | Default |
|---|---|---|
| `SECRET_KEY` | Flask session secret | dev value |
| `DATABASE_URL` | SQLAlchemy URL | `sqlite:///data/app.db` |
| `LLM_PROVIDER` | `mock` / `openai` / `anthropic` / `gemini` / `ollama` | `mock` |
| `OPENAI_API_KEY` etc. | Provider credentials | empty |
| `WHATSAPP_NUMBER` | International, digits only | `8801XXXXXXXXX` |
| `WHATSAPP_GREETING` | Prefilled msg on FAB | see `.env.example` |
| `CONFIDENCE_THRESHOLD` | RAG cosine cutoff for escalation | `0.35` |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD_HASH` | Admin seed | `araf` / `changeme` |

Generate a strong password hash:
```bash
python -c "from werkzeug.security import generate_password_hash;print(generate_password_hash('YourStrongPass'))"
```

---

## 📚 Feeding the Knowledge Base

Drop files into `knowledge_base/` (`.pdf`, `.docx`, `.md`, `.txt`) or upload via **Admin → Uploads**.
Then click **Reindex Knowledge Base** on the admin dashboard (or `POST /api/reindex`).

---

## 🤖 Switching LLM Provider

Set `LLM_PROVIDER` in `.env`:

```
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
```

Adding a new provider is a 15-line class in `app/services/llm_provider.py`.

---

## 🌐 Deployment — Three Paths

### ⚠️ Netlify limitation
Netlify **cannot host a long-running Python Flask server**. Options:

### ✅ Option A — Netlify (frontend) + Render/Railway/Fly.io (Flask backend) — RECOMMENDED

1. Deploy this Flask repo to Render (uses `render.yaml`) or Fly (`fly.toml`) or Railway (`Procfile`).
2. Note the backend URL, e.g. `https://arafmustavi-portfolio.onrender.com`.
3. In `netlify.toml`, replace `YOUR-BACKEND-HOST.example.com` with that URL.
4. Optional: build a static landing page and drop it in `public/`. All chat/API traffic will proxy through Netlify to your Flask backend.

### 🟡 Option B — Netlify Functions (serverless-wsgi)

Install `serverless-wsgi` and wrap `create_app()` in a function. Note: cold-starts + read-only file system make RAG uploads brittle. Fine for demos only.

### 🟢 Option C — Single-host on Render / Railway / Fly.io — SIMPLEST

```bash
# Render:  push repo, it reads render.yaml
# Fly:     fly launch  (uses fly.toml + Dockerfile)
# Railway: connect repo, it reads Procfile
# Docker:  docker compose up --build
```

The Flask app already serves the full site + API from one process.

---

## 🏗 Architecture

```
Browser
  ├── /  → Jinja templates (SSR)
  ├── /api/chat  → RAGService.retrieve()  → LLMProvider.generate()
  │                          │                        │
  │                       Chunks              (mock|openai|anthropic|
  │                                            gemini|ollama)
  │                          │
  │                   knowledge_base/*.{pdf,docx,md,txt} + DB entities
  │
  └── /admin  → Flask-Login gated dashboard
```

Clean separation:
- `blueprints/` — HTTP layer
- `services/` — RAG, LLM, WhatsApp (framework-agnostic)
- `models/` — SQLAlchemy models
- `templates/` + `static/` — presentation

---

## 🧩 Extending

**Add a new page**: create blueprint in `app/blueprints/`, register in `app/__init__.py`.

**Add a new LLM provider**: subclass `LLMProvider` in `services/llm_provider.py`, add branch in `get_llm_provider()`.

**Upgrade embeddings**: replace `_embed()` in `services/rag_service.py` with an OpenAI embeddings call and swap the retrieval to a proper vector DB (pgvector / Qdrant).

**Add WhatsApp Business API**: create `services/whatsapp_business.py` and swap the wa.me link builder.

---

## 🧪 Tests

```bash
pytest
```

---

## 🗂 Folder Structure

```
app/
  blueprints/    main.py · api.py · admin.py
  services/      llm_provider.py · rag_service.py · knowledge_base.py · whatsapp_service.py
  models/models.py
  templates/     base.html · index.html · about.html · … · admin/*.html
  static/        css/ · js/ · img/
knowledge_base/  drop your docs here
data/            SQLite DB + uploads
tests/           pytest suite
```

---

## 📝 Credits & Links

- LinkedIn: https://www.linkedin.com/in/arafmustavi/
- Previous portfolio: https://arafmustavi.netlify.app/
- GitHub: https://github.com/arafmustavi
