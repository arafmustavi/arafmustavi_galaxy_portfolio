# Araf Mustavi — AI-Powered Portfolio (Flask, **No Database**)

A production-ready personal portfolio with:
- Modern responsive Flask website (dark galaxy theme + Tailwind)
- Floating WhatsApp button with pre-filled greeting
- **AI chat assistant** grounded in Araf's docs via RAG
- Automatic **WhatsApp escalation** when the AI isn't confident
- Admin dashboard (auth, uploads, projects, chat logs, reindex)
- Pluggable LLM providers (OpenAI · Anthropic · Gemini · Ollama · Mock)
- **Zero database** — all content lives in plain JSON files under `content/`

---

## 🚀 Quick Start

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # edit as needed
python seed.py                                        # creates default content/*.json
python run.py
```

Visit **http://localhost:5000**. Admin: **/admin/login** (default `araf` / `changeme` — change immediately by setting `ADMIN_PASSWORD_HASH`).

The app runs out-of-the-box with **no API keys** using the built-in `MockLLMProvider`.

---

## 📝 Editing Content

**All content is in `content/*.json`.** Just open the files in your editor and save — refresh the browser.

| File | What's inside |
|---|---|
| `content/profile.json` | Name, title, tagline, bio, location, socials |
| `content/experience.json` | Work history |
| `content/projects.json` | Projects (mark `"featured": true` to show on home) |
| `content/certifications.json` | Certifications |
| `content/publications.json` | Publications |
| `content/courses.json` | Courses you teach |
| `content/blog.json` | Blog posts (ISO date strings) |
| `content/faqs.json` | FAQ items shown on /contact |

You can also add entries via the **Admin → Projects** UI, which appends to the same JSON files.

Chat logs are appended to **`data/chat_logs.jsonl`** (one JSON object per line).

---

## 🔑 Environment Variables

| Var | Purpose | Default |
|---|---|---|
| `SECRET_KEY` | Flask session secret | dev value |
| `CONTENT_DIR` | Where JSON content lives | `content` |
| `LLM_PROVIDER` | `mock` / `openai` / `anthropic` / `gemini` / `ollama` | `mock` |
| `OPENAI_API_KEY` etc. | Provider credentials | empty |
| `WHATSAPP_NUMBER` | International, digits only | `8801XXXXXXXXX` |
| `WHATSAPP_GREETING` | Prefilled msg on FAB | see `.env.example` |
| `CONFIDENCE_THRESHOLD` | RAG cosine cutoff for escalation | `0.35` |
| `ADMIN_USERNAME` / `ADMIN_PASSWORD_HASH` | Admin login | `araf` / dev fallback `changeme` |

Generate a strong password hash:
```bash
python -c "from werkzeug.security import generate_password_hash;print(generate_password_hash('YourStrongPass'))"
```

---

## 📚 Feeding the Knowledge Base (RAG)

Drop files into `knowledge_base/` (`.pdf`, `.docx`, `.md`, `.txt`) or upload via **Admin → Uploads**.
Then click **Reindex Knowledge Base** on the admin dashboard (or `POST /api/reindex`).

The RAG index also includes **all `content/*.json` entries automatically**.

---

## 🤖 Switching LLM Provider

Set `LLM_PROVIDER` in `.env`:

```
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
```

Adding a new provider is a ~15-line class in `app/services/llm_provider.py`.

---

## 🌐 Deployment — Three Paths

### ⚠️ Netlify limitation
Netlify **cannot host a long-running Python Flask server.** Options:

### ✅ Option A — Netlify (frontend shell) + Render/Railway/Fly.io (Flask) — RECOMMENDED
1. Deploy this Flask repo to Render (uses `render.yaml`) / Fly (`fly.toml`) / Railway (`Procfile`).
2. Note the backend URL, e.g. `https://arafmustavi-portfolio.onrender.com`.
3. In `netlify.toml`, replace `YOUR-BACKEND-HOST.example.com` with that URL.
4. Netlify proxies `/api/*` to Flask; chat + escalation work from your Netlify domain.

### 🟢 Option B — Single-host on Render / Railway / Fly.io / Docker — SIMPLEST
```bash
# Render:  push repo, it reads render.yaml
# Fly:     fly launch  (uses fly.toml + Dockerfile)
# Railway: connect repo, reads Procfile
# Docker:  docker compose up --build
```

### 🟡 Option C — Netlify Functions (serverless-wsgi)
Not recommended for RAG workloads. Fine for demos.

### 💾 Persistence
No database provisioning needed. Just make sure `content/`, `knowledge_base/`,
and `data/` **persist** (mount as volumes on Fly/Docker; on Render use a disk).

---

## 🏗 Architecture

```
Browser
  ├── /               → Jinja templates
  │      (reads profile/projects/etc. from ContentStore → content/*.json)
  ├── /api/chat       → RAGService.retrieve() → LLMProvider.generate()
  │                       │                        │
  │                    Chunks              (mock|openai|anthropic|gemini|ollama)
  │                       │
  │                content/*.json + knowledge_base/{pdf,docx,md,txt}
  │
  └── /admin          → Flask-Login gated dashboard
```

Clean separation:
- `blueprints/` — HTTP layer
- `services/` — ContentStore, RAG, LLM, WhatsApp (framework-agnostic)
- `templates/` + `static/` — presentation

---

## 🧩 Extending

- **New content type**: add a filename to `ContentStore.FILES`, add an accessor, add a blueprint route + template.
- **New LLM provider**: subclass `LLMProvider` in `services/llm_provider.py`.
- **Upgrade embeddings**: replace `_embed()` in `services/rag_service.py` with real embeddings + a vector DB.

---

## 🧪 Tests

```bash
pytest
```

---

## 🗂 Folder Structure

```
app/
  blueprints/    main.py · api.py · admin.py
  services/      content_store.py · llm_provider.py · rag_service.py · knowledge_base.py · whatsapp_service.py
  templates/     base.html · index.html · about.html · … · admin/*.html
  static/        css/ · js/ · img/
content/         profile.json · experience.json · projects.json · …    ← edit here!
knowledge_base/  drop resume.pdf / cv.pdf / *.md here for RAG
data/            chat_logs.jsonl + uploads
tests/           pytest suite
```

---

## 📌 Credits & Links

- LinkedIn: https://www.linkedin.com/in/arafmustavi/
- Previous portfolio: https://arafmustavi.netlify.app/
- GitHub: https://github.com/arafmustavi
