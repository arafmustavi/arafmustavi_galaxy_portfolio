"""Flask application factory (file-based, no DB)."""
from __future__ import annotations
import logging
import os
from flask import Flask
from dotenv import load_dotenv

from .config import get_config
from .extensions import login_manager
from .services.content_store import ContentStore


def create_app(config_name: str | None = None) -> Flask:
    """Create and configure the Flask app instance."""
    load_dotenv()
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(get_config(config_name))

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    project_root = os.path.abspath(os.path.join(app.root_path, ".."))
    os.makedirs(os.path.join(project_root, "data"), exist_ok=True)
    os.makedirs(os.path.join(project_root, "data", "uploads"), exist_ok=True)

    content_dir = app.config.get("CONTENT_DIR", "content")
    if not os.path.isabs(content_dir):
        content_dir = os.path.join(project_root, content_dir)
    os.makedirs(content_dir, exist_ok=True)

    # Attach a single ContentStore instance to the app
    app.content = ContentStore(content_dir, data_dir=os.path.join(project_root, "data"))

    # Extensions
    login_manager.init_app(app)
    login_manager.login_view = "admin.login"

    # Blueprints
    from .blueprints.main import main_bp
    from .blueprints.api import api_bp
    from .blueprints.admin import admin_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp, url_prefix="/api")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    @app.context_processor
    def inject_globals():
        return {
            "WHATSAPP_NUMBER": app.config.get("WHATSAPP_NUMBER"),
            "WHATSAPP_GREETING": app.config.get("WHATSAPP_GREETING"),
            "SITE_OWNER": "Araf Mustavi",
            "profile": app.content.profile(),
        }

    return app
