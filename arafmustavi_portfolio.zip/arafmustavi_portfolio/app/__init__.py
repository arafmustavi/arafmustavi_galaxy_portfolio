"""Flask application factory."""
from __future__ import annotations
import logging
import os
from flask import Flask
from dotenv import load_dotenv

from .config import get_config
from .extensions import db, login_manager


def create_app(config_name: str | None = None) -> Flask:
    """Create and configure the Flask app instance."""
    load_dotenv()
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(get_config(config_name))

    # Logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # Ensure data dir exists
    os.makedirs(os.path.join(app.root_path, "..", "data"), exist_ok=True)
    os.makedirs(os.path.join(app.root_path, "..", "data", "uploads"), exist_ok=True)

    # Extensions
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "admin.login"

    # Blueprints
    from .blueprints.main import main_bp
    from .blueprints.api import api_bp
    from .blueprints.admin import admin_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp, url_prefix="/api")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    # Models must be imported before create_all
    from .models import models  # noqa: F401

    with app.app_context():
        db.create_all()

    # Template globals
    @app.context_processor
    def inject_globals():
        return {
            "WHATSAPP_NUMBER": app.config.get("WHATSAPP_NUMBER"),
            "WHATSAPP_GREETING": app.config.get("WHATSAPP_GREETING"),
            "SITE_OWNER": "Araf Mustavi",
        }

    return app
