"""Admin dashboard: auth-gated management UI."""
from __future__ import annotations
import os
from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from flask_login import login_required, login_user, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from ..extensions import db
from ..models.models import AdminUser, Project, Certification, BlogPost, ChatLog, FAQ

admin_bp = Blueprint("admin", __name__, template_folder="../templates/admin")


def _ensure_admin_seed():
    """Create admin user from env on first request if none exists."""
    if AdminUser.query.count() > 0:
        return
    username = current_app.config["ADMIN_USERNAME"]
    pw_hash = current_app.config["ADMIN_PASSWORD_HASH"] or generate_password_hash("changeme")
    db.session.add(AdminUser(username=username, password_hash=pw_hash))
    db.session.commit()


@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    _ensure_admin_seed()
    if request.method == "POST":
        u = request.form.get("username", "")
        p = request.form.get("password", "")
        user = AdminUser.query.filter_by(username=u).first()
        if user and check_password_hash(user.password_hash, p):
            login_user(user)
            return redirect(url_for("admin.dashboard"))
        flash("Invalid credentials", "error")
    return render_template("admin/login.html")


@admin_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.index"))


@admin_bp.route("/")
@login_required
def dashboard():
    stats = {
        "projects": Project.query.count(),
        "certifications": Certification.query.count(),
        "blog_posts": BlogPost.query.count(),
        "chats": ChatLog.query.count(),
        "escalations": ChatLog.query.filter_by(escalated=True).count(),
    }
    return render_template("admin/dashboard.html", stats=stats)


@admin_bp.route("/projects", methods=["GET", "POST"])
@login_required
def projects():
    if request.method == "POST":
        p = Project(
            title=request.form.get("title", "").strip(),
            summary=request.form.get("summary", "").strip(),
            description=request.form.get("description", "").strip(),
            tech_stack=request.form.get("tech_stack", "").strip(),
            url=request.form.get("url", "").strip(),
            github_url=request.form.get("github_url", "").strip(),
            year=request.form.get("year", "").strip(),
            featured=bool(request.form.get("featured")),
        )
        db.session.add(p)
        db.session.commit()
        flash("Project added", "success")
        return redirect(url_for("admin.projects"))
    items = Project.query.all()
    return render_template("admin/projects.html", items=items)


ALLOWED_EXT = {"pdf", "docx", "md", "txt", "png", "jpg", "jpeg", "webp"}


@admin_bp.route("/uploads", methods=["GET", "POST"])
@login_required
def uploads():
    if request.method == "POST":
        f = request.files.get("file")
        if not f or "." not in f.filename:
            flash("No file selected", "error")
            return redirect(url_for("admin.uploads"))
        ext = f.filename.rsplit(".", 1)[1].lower()
        if ext not in ALLOWED_EXT:
            flash("File type not allowed", "error")
            return redirect(url_for("admin.uploads"))
        name = secure_filename(f.filename)
        target_dir = current_app.config["KNOWLEDGE_BASE_DIR"] if ext in {"pdf", "docx", "md", "txt"} \
            else os.path.join("data", "uploads")
        os.makedirs(target_dir, exist_ok=True)
        f.save(os.path.join(target_dir, name))
        flash(f"Uploaded {name}", "success")
        return redirect(url_for("admin.uploads"))
    return render_template("admin/uploads.html")


@admin_bp.route("/chat-logs")
@login_required
def chat_logs():
    logs = ChatLog.query.order_by(ChatLog.created_at.desc()).limit(200).all()
    return render_template("admin/chat_logs.html", logs=logs)


@admin_bp.route("/reindex", methods=["POST"])
@login_required
def reindex():
    from .api import _get_rag
    global_rag = _get_rag
    # Force rebuild
    from . import api as api_mod
    api_mod._rag = None
    api_mod._get_rag()
    flash("Knowledge base reindexed", "success")
    return redirect(url_for("admin.dashboard"))
