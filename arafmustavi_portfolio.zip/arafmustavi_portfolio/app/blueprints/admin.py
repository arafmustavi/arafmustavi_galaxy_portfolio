"""Admin dashboard: auth-gated, file-based storage."""
from __future__ import annotations
import logging
import os
from flask import (
    Blueprint, current_app, flash, redirect, render_template, request, url_for,
)
from flask_login import UserMixin, login_required, login_user, logout_user
from werkzeug.security import check_password_hash
from werkzeug.utils import secure_filename

from ..extensions import login_manager

log = logging.getLogger(__name__)
admin_bp = Blueprint("admin", __name__, template_folder="../templates/admin")


class AdminUser(UserMixin):
    """Single in-memory admin, seeded from env config."""
    def __init__(self, id_: int, username: str):
        self.id = id_
        self.username = username

    def get_id(self) -> str:
        return str(self.id)


def _current_admin() -> AdminUser:
    return AdminUser(1, current_app.config.get("ADMIN_USERNAME", "araf"))


@login_manager.user_loader
def load_user(user_id: str):
    try:
        if int(user_id) == 1:
            return _current_admin()
    except ValueError:
        pass
    return None


def _check_password(submitted: str) -> bool:
    """Verify submitted password against env hash, or dev fallback."""
    pw_hash = current_app.config.get("ADMIN_PASSWORD_HASH") or ""
    if pw_hash:
        try:
            return check_password_hash(pw_hash, submitted)
        except Exception as e:
            log.warning("Password hash check failed: %s", e)
            return False
    log.warning("ADMIN_PASSWORD_HASH not set — using dev fallback 'changeme'. Set it before production!")
    return submitted == "changeme"


@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username", "")
        p = request.form.get("password", "")
        expected_user = current_app.config.get("ADMIN_USERNAME", "araf")
        if u == expected_user and _check_password(p):
            login_user(_current_admin())
            return redirect(url_for("admin.dashboard"))
        flash("Invalid credentials", "error")
    return render_template("admin/login.html")


@admin_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.index"))


@admin_bp.route("/")
@login_required
def dashboard():
    store = current_app.content
    chat_stats = store.chat_log_stats()
    stats = {
        "projects":       len(store.load("projects") or []),
        "certifications": len(store.load("certifications") or []),
        "blog_posts":     len(store.load("blog") or []),
        "chats":          chat_stats["total"],
        "escalations":    chat_stats["escalations"],
    }
    return render_template("admin/dashboard.html", stats=stats)


@admin_bp.route("/projects", methods=["GET", "POST"])
@login_required
def projects():
    store = current_app.content
    if request.method == "POST":
        item = {
            "title":       request.form.get("title", "").strip(),
            "summary":     request.form.get("summary", "").strip(),
            "description": request.form.get("description", "").strip(),
            "tech_stack":  request.form.get("tech_stack", "").strip(),
            "url":         request.form.get("url", "").strip(),
            "github_url":  request.form.get("github_url", "").strip(),
            "year":        request.form.get("year", "").strip(),
            "featured":    bool(request.form.get("featured")),
        }
        store.append("projects", item)
        flash("Project added", "success")
        return redirect(url_for("admin.projects"))
    return render_template("admin/projects.html", items=store.projects())


ALLOWED_EXT = {"pdf", "docx", "md", "txt", "png", "jpg", "jpeg", "webp"}


@admin_bp.route("/uploads", methods=["GET", "POST"])
@login_required
def uploads():
    if request.method == "POST":
        f = request.files.get("file")
        if not f or "." not in f.filename:
            flash("No file selected", "error")
            return redirect(url_for("admin.uploads"))
        ext = f.filename.rsplit(".", 1)[1].lower()
        if ext not in ALLOWED_EXT:
            flash("File type not allowed", "error")
            return redirect(url_for("admin.uploads"))
        name = secure_filename(f.filename)
        if ext in {"pdf", "docx", "md", "txt"}:
            target_dir = current_app.config["KNOWLEDGE_BASE_DIR"]
        else:
            target_dir = os.path.join("data", "uploads")
        os.makedirs(target_dir, exist_ok=True)
        f.save(os.path.join(target_dir, name))
        flash(f"Uploaded {name}", "success")
        return redirect(url_for("admin.uploads"))
    return render_template("admin/uploads.html")


@admin_bp.route("/chat-logs")
@login_required
def chat_logs():
    logs = current_app.content.read_chat_logs(limit=200)
    return render_template("admin/chat_logs.html", logs=logs)


@admin_bp.route("/reindex", methods=["POST"])
@login_required
def reindex():
    from . import api as api_mod
    api_mod.reset_rag()
    api_mod._get_rag()
    flash("Knowledge base reindexed", "success")
    return redirect(url_for("admin.dashboard"))
