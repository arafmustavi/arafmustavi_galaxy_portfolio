"""Public API: chat + escalation."""
from __future__ import annotations
import logging
import uuid
from flask import Blueprint, current_app, jsonify, request

from ..extensions import db
from ..models.models import ChatLog, Project, Certification, Experience, FAQ
from ..services.llm_provider import get_llm_provider
from ..services.rag_service import RAGService
from ..services.whatsapp_service import build_whatsapp_url, summarize_conversation

log = logging.getLogger(__name__)
api_bp = Blueprint("api", __name__)

_rag: RAGService | None = None


def _db_docs() -> list[str]:
    docs = []
    for p in Project.query.all():
        docs.append(
            f"Project: {p.title}. {p.summary or ''} {p.description or ''} "
            f"Tech: {p.tech_stack or ''}. Year: {p.year or ''}."
        )
    for c in Certification.query.all():
        docs.append(f"Certification: {c.title} from {c.issuer or ''} ({c.year or ''}).")
    for e in Experience.query.all():
        docs.append(
            f"Experience: {e.role} at {e.company or ''} ({e.period or ''}). "
            f"{e.description or ''}"
        )
    for f in FAQ.query.all():
        docs.append(f"FAQ: {f.question} Answer: {f.answer}")
    return docs


def _get_rag() -> RAGService:
    global _rag
    if _rag is None:
        _rag = RAGService(
            base_dir=current_app.config["KNOWLEDGE_BASE_DIR"],
            extra_docs=_db_docs(),
        )
    return _rag


@api_bp.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    session_id = data.get("session_id") or str(uuid.uuid4())

    if not message:
        return jsonify({"error": "message is required"}), 400

    rag = _get_rag()
    retrieved = rag.retrieve(message, top_k=3)
    top_score = retrieved[0][1] if retrieved else 0.0
    context = [c.text for c, _ in retrieved]

    llm = get_llm_provider()
    reply = llm.generate(message, context)

    threshold = current_app.config["CONFIDENCE_THRESHOLD"]
    escalate = top_score < threshold

    wa_url = None
    if escalate:
        wa_url = build_whatsapp_url(
            current_app.config["WHATSAPP_NUMBER"],
            summarize_conversation(message, reply),
        )

    # Log
    try:
        db.session.add(ChatLog(
            session_id=session_id,
            user_message=message,
            bot_reply=reply,
            confidence=top_score,
            escalated=escalate,
        ))
        db.session.commit()
    except Exception as e:
        log.exception("Failed to log chat: %s", e)

    return jsonify({
        "session_id": session_id,
        "reply": reply,
        "confidence": round(top_score, 3),
        "escalate": escalate,
        "whatsapp_url": wa_url,
        "escalate_message": "I'd like Araf to answer this personally." if escalate else None,
    })


@api_bp.route("/escalate", methods=["POST"])
def escalate():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    reply = data.get("last_reply", "")
    wa_url = build_whatsapp_url(
        current_app.config["WHATSAPP_NUMBER"],
        summarize_conversation(message, reply),
    )
    return jsonify({"whatsapp_url": wa_url})


@api_bp.route("/reindex", methods=["POST"])
def reindex():
    """Trigger a knowledge-base rebuild (admin should protect this in prod)."""
    global _rag
    _rag = None
    _get_rag()
    return jsonify({"status": "reindexed"})
