"""Public API: chat + escalation. File-based, no DB."""
from __future__ import annotations
import logging
import uuid
from datetime import datetime
from flask import Blueprint, current_app, jsonify, request

from ..services.llm_provider import get_llm_provider
from ..services.rag_service import RAGService
from ..services.whatsapp_service import build_whatsapp_url, summarize_conversation

log = logging.getLogger(__name__)
api_bp = Blueprint("api", __name__)

_rag: RAGService | None = None


def _content_docs() -> list[str]:
    """Flatten ContentStore items into plain-text docs for RAG."""
    store = current_app.content
    docs: list[str] = []

    profile = store.load("profile") or {}
    if profile:
        docs.append(
            f"Profile: {profile.get('name','')} — {profile.get('title','')}. "
            f"{profile.get('tagline','')} Location: {profile.get('location','')}. "
            f"LinkedIn: {profile.get('linkedin','')}, GitHub: {profile.get('github','')}."
        )

    for p in store.load("projects") or []:
        docs.append(
            f"Project: {p.get('title','')}. {p.get('summary','')} {p.get('description','')} "
            f"Tech: {p.get('tech_stack','')}. Year: {p.get('year','')}."
        )
    for c in store.load("certifications") or []:
        docs.append(f"Certification: {c.get('title','')} from {c.get('issuer','')} ({c.get('year','')}).")
    for e in store.load("experiences") or []:
        docs.append(
            f"Experience: {e.get('role','')} at {e.get('company','')} ({e.get('period','')}). "
            f"{e.get('description','')}"
        )
    for f in store.load("faqs") or []:
        docs.append(f"FAQ: {f.get('question','')} Answer: {f.get('answer','')}")
    for b in store.load("blog") or []:
        docs.append(f"Blog: {b.get('title','')}. {b.get('excerpt','')}")
    for c in store.load("courses") or []:
        docs.append(f"Course: {c.get('title','')} on {c.get('platform','')}. {c.get('description','')}")
    for p in store.load("publications") or []:
        docs.append(f"Publication: {p.get('title','')} in {p.get('venue','')} ({p.get('year','')}).")

    return docs


def _get_rag() -> RAGService:
    global _rag
    if _rag is None:
        _rag = RAGService(
            base_dir=current_app.config["KNOWLEDGE_BASE_DIR"],
            extra_docs=_content_docs(),
        )
    return _rag


def reset_rag() -> None:
    """Force a rebuild on next request."""
    global _rag
    _rag = None


@api_bp.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    session_id = data.get("session_id") or str(uuid.uuid4())

    if not message:
        return jsonify({"error": "message is required"}), 400

    rag = _get_rag()
    retrieved = rag.retrieve(message, top_k=3)
    top_score = retrieved[0][1] if retrieved else 0.0
    context = [c.text for c, _ in retrieved]

    llm = get_llm_provider()
    reply = llm.generate(message, context)

    threshold = current_app.config["CONFIDENCE_THRESHOLD"]
    escalate = top_score < threshold

    wa_url = None
    if escalate:
        wa_url = build_whatsapp_url(
            current_app.config["WHATSAPP_NUMBER"],
            summarize_conversation(message, reply),
        )

    current_app.content.append_chat_log({
        "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "session_id": session_id,
        "user_message": message,
        "bot_reply": reply,
        "confidence": round(float(top_score), 3),
        "escalated": bool(escalate),
    })

    return jsonify({
        "session_id": session_id,
        "reply": reply,
        "confidence": round(top_score, 3),
        "escalate": escalate,
        "whatsapp_url": wa_url,
        "escalate_message": "I'd like Araf to answer this personally." if escalate else None,
    })


@api_bp.route("/escalate", methods=["POST"])
def escalate():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    reply = data.get("last_reply", "")
    wa_url = build_whatsapp_url(
        current_app.config["WHATSAPP_NUMBER"],
        summarize_conversation(message, reply),
    )
    return jsonify({"whatsapp_url": wa_url})


@api_bp.route("/reindex", methods=["POST"])
def reindex():
    reset_rag()
    _get_rag()
    return jsonify({"status": "reindexed"})
