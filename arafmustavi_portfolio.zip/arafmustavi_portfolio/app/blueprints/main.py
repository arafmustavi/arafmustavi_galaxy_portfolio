"""Public site pages — reads everything from ContentStore."""
from __future__ import annotations
from flask import Blueprint, current_app, render_template

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    return render_template("index.html", projects=current_app.content.featured_projects())


@main_bp.route("/about")
def about():
    return render_template("about.html")


@main_bp.route("/experience")
def experience():
    return render_template("experience.html", items=current_app.content.experiences())


@main_bp.route("/projects")
def projects():
    return render_template("projects.html", items=current_app.content.projects())


@main_bp.route("/certifications")
def certifications():
    return render_template("certifications.html", items=current_app.content.certifications())


@main_bp.route("/publications")
def publications():
    return render_template("publications.html", items=current_app.content.publications())


@main_bp.route("/courses")
def courses():
    return render_template("courses.html", items=current_app.content.courses())


@main_bp.route("/blog")
def blog():
    return render_template("blog.html", items=current_app.content.blog_posts())


@main_bp.route("/contact")
def contact():
    return render_template("contact.html", faqs=current_app.content.faqs())


@main_bp.route("/healthz")
def healthz():
    return {"status": "ok"}
