"""Public site pages."""
from __future__ import annotations
from flask import Blueprint, render_template
from ..models.models import (
    Project, Certification, Experience, BlogPost, Course, Publication, FAQ
)

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    projects = Project.query.filter_by(featured=True).all()
    return render_template("index.html", projects=projects)


@main_bp.route("/about")
def about():
    return render_template("about.html")


@main_bp.route("/experience")
def experience():
    items = Experience.query.order_by(Experience.order.desc()).all()
    return render_template("experience.html", items=items)


@main_bp.route("/projects")
def projects():
    items = Project.query.all()
    return render_template("projects.html", items=items)


@main_bp.route("/certifications")
def certifications():
    items = Certification.query.all()
    return render_template("certifications.html", items=items)


@main_bp.route("/publications")
def publications():
    items = Publication.query.all()
    return render_template("publications.html", items=items)


@main_bp.route("/courses")
def courses():
    items = Course.query.all()
    return render_template("courses.html", items=items)


@main_bp.route("/blog")
def blog():
    items = BlogPost.query.order_by(BlogPost.published_at.desc()).all()
    return render_template("blog.html", items=items)


@main_bp.route("/contact")
def contact():
    faqs = FAQ.query.all()
    return render_template("contact.html", faqs=faqs)


@main_bp.route("/healthz")
def healthz():
    return {"status": "ok"}
