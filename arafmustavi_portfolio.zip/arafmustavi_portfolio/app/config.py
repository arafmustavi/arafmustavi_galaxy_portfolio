"""Configuration classes."""
from __future__ import annotations
import os


class BaseConfig:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", "sqlite:///data/app.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    LLM_PROVIDER = os.getenv("LLM_PROVIDER", "mock")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
    OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")

    WHATSAPP_NUMBER = os.getenv("WHATSAPP_NUMBER", "8801XXXXXXXXX")
    WHATSAPP_GREETING = os.getenv(
        "WHATSAPP_GREETING",
        "Hi Araf, I found your website and would like to know more.",
    )

    CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "0.35"))
    KNOWLEDGE_BASE_DIR = os.getenv("KNOWLEDGE_BASE_DIR", "knowledge_base")

    ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "araf")
    ADMIN_PASSWORD_HASH = os.getenv("ADMIN_PASSWORD_HASH", "")


class DevelopmentConfig(BaseConfig):
    DEBUG = True


class ProductionConfig(BaseConfig):
    DEBUG = False


def get_config(name: str | None = None):
    env = (name or os.getenv("FLASK_ENV", "development")).lower()
    return ProductionConfig if env == "production" else DevelopmentConfig
