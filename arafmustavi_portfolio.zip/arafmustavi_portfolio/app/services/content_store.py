"""File-based content store: JSON per collection + JSONL for chat logs.

No database is used. All content lives under `content/` and is
hot-editable in any text editor.
"""
from __future__ import annotations
import json
import logging
import os
from types import SimpleNamespace
from typing import Any, Iterable

log = logging.getLogger(__name__)


def _to_ns(obj: Any) -> Any:
    """Recursively convert dicts to SimpleNamespace for dot-access in Jinja."""
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: _to_ns(v) for k, v in obj.items()})
    if isinstance(obj, list):
        return [_to_ns(x) for x in obj]
    return obj


class ContentStore:
    """Read/write JSON files for all site content."""

    FILES = {
        "profile":        "profile.json",
        "experiences":    "experience.json",
        "projects":       "projects.json",
        "certifications": "certifications.json",
        "publications":   "publications.json",
        "courses":        "courses.json",
        "blog":           "blog.json",
        "faqs":           "faqs.json",
    }

    def __init__(self, content_dir: str, data_dir: str):
        self.content_dir = content_dir
        self.data_dir = data_dir
        os.makedirs(self.content_dir, exist_ok=True)
        os.makedirs(self.data_dir, exist_ok=True)
        self.chat_log_path = os.path.join(self.data_dir, "chat_logs.jsonl")

    # ---------------- generic ----------------
    def _path(self, name: str) -> str:
        fname = self.FILES.get(name, f"{name}.json")
        return os.path.join(self.content_dir, fname)

    def load(self, name: str) -> Any:
        """Load raw JSON (dict/list). Returns [] or {} if missing."""
        path = self._path(name)
        if not os.path.exists(path):
            return {} if name == "profile" else []
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            log.warning("Failed to read %s: %s", path, e)
            return {} if name == "profile" else []

    def save(self, name: str, data: Any) -> None:
        path = self._path(name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    # ---------------- typed accessors (return SimpleNamespace for Jinja) ----------------
    def profile(self) -> SimpleNamespace:
        return _to_ns(self.load("profile") or {})

    def experiences(self) -> list:
        items = self.load("experiences") or []
        items.sort(key=lambda x: x.get("order", 0), reverse=True)
        return _to_ns(items)

    def projects(self) -> list:
        return _to_ns(self.load("projects") or [])

    def featured_projects(self) -> list:
        return [p for p in self.projects() if getattr(p, "featured", False)]

    def certifications(self) -> list:
        return _to_ns(self.load("certifications") or [])

    def publications(self) -> list:
        return _to_ns(self.load("publications") or [])

    def courses(self) -> list:
        return _to_ns(self.load("courses") or [])

    def blog_posts(self) -> list:
        items = self.load("blog") or []
        items.sort(key=lambda x: x.get("published_at", ""), reverse=True)
        return _to_ns(items)

    def faqs(self) -> list:
        return _to_ns(self.load("faqs") or [])

    # ---------------- writes (admin) ----------------
    def append(self, name: str, item: dict) -> dict:
        raw = self.load(name)
        if not isinstance(raw, list):
            raw = []
        next_id = max((int(x.get("id", 0)) for x in raw), default=0) + 1
        item["id"] = next_id
        raw.append(item)
        self.save(name, raw)
        return item

    # ---------------- chat logs (JSONL append-only) ----------------
    def append_chat_log(self, entry: dict) -> None:
        try:
            with open(self.chat_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            log.exception("Failed to append chat log: %s", e)

    def read_chat_logs(self, limit: int = 200) -> list:
        if not os.path.exists(self.chat_log_path):
            return []
        try:
            with open(self.chat_log_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            entries = []
            for line in lines[-limit:]:
                line = line.strip()
                if not line:
                    continue
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
            entries.reverse()
            return _to_ns(entries)
        except Exception as e:
            log.warning("Failed to read chat logs: %s", e)
            return []

    def chat_log_stats(self) -> dict:
        entries = []
        if os.path.exists(self.chat_log_path):
            with open(self.chat_log_path, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        entries.append(json.loads(line))
                    except Exception:
                        pass
        escalations = sum(1 for e in entries if e.get("escalated"))
        return {"total": len(entries), "escalations": escalations}
