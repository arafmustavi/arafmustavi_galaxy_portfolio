"""Knowledge base loader: reads and chunks documents from disk."""
from __future__ import annotations
import logging
import os
from dataclasses import dataclass
from typing import List

log = logging.getLogger(__name__)


@dataclass
class Chunk:
    source: str
    text: str


def _read_pdf(path: str) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        return "\n".join((p.extract_text() or "") for p in reader.pages)
    except Exception as e:
        log.warning("PDF read failed for %s: %s", path, e)
        return ""


def _read_docx(path: str) -> str:
    try:
        import docx
        d = docx.Document(path)
        return "\n".join(p.text for p in d.paragraphs)
    except Exception as e:
        log.warning("DOCX read failed for %s: %s", path, e)
        return ""


def _read_text(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        log.warning("Text read failed for %s: %s", path, e)
        return ""


def _chunk(text: str, size: int = 500, overlap: int = 80) -> List[str]:
    text = " ".join(text.split())
    if not text:
        return []
    chunks = []
    i = 0
    while i < len(text):
        chunks.append(text[i:i + size])
        i += size - overlap
    return chunks


def load_knowledge_base(base_dir: str) -> List[Chunk]:
    """Walk `base_dir` and return chunked documents."""
    results: List[Chunk] = []
    if not os.path.isdir(base_dir):
        log.info("Knowledge base dir %s not found; skipping.", base_dir)
        return results

    for root, _, files in os.walk(base_dir):
        for fname in files:
            path = os.path.join(root, fname)
            ext = fname.lower().rsplit(".", 1)[-1]
            if ext == "pdf":
                raw = _read_pdf(path)
            elif ext == "docx":
                raw = _read_docx(path)
            elif ext in ("md", "txt", "markdown"):
                raw = _read_text(path)
            else:
                continue
            for c in _chunk(raw):
                results.append(Chunk(source=fname, text=c))
    log.info("Loaded %d knowledge chunks from %s", len(results), base_dir)
    return results
