"""LLM provider strategy pattern.

Supports mock (default), OpenAI, Anthropic, Gemini, and Ollama.
All providers implement `generate(prompt, context) -> str`.
"""
from __future__ import annotations
import logging
import os
from abc import ABC, abstractmethod
from typing import List

import requests

log = logging.getLogger(__name__)


class LLMProvider(ABC):
    @abstractmethod
    def generate(self, question: str, context_chunks: List[str]) -> str:
        ...


def _build_prompt(question: str, context_chunks: List[str]) -> str:
    context = "\n\n".join(context_chunks) if context_chunks else "(no context available)"
    return (
        "You are Araf Mustavi's personal AI assistant on his portfolio website. "
        "Answer visitor questions about Araf using ONLY the context below. "
        "Be concise, professional, and friendly. If context is insufficient, say you'll "
        "connect them with Araf on WhatsApp.\n\n"
        f"Context:\n{context}\n\n"
        f"Visitor Question: {question}\n"
        "Answer:"
    )


class MockLLMProvider(LLMProvider):
    """No-key provider: composes a helpful answer from retrieved chunks."""

    def generate(self, question: str, context_chunks: List[str]) -> str:
        if not context_chunks:
            return (
                "I don't have that information yet. Let me connect you with Araf on WhatsApp."
            )
        snippet = " ".join(context_chunks[:2])
        snippet = snippet.replace("\n", " ").strip()
        if len(snippet) > 600:
            snippet = snippet[:600].rsplit(" ", 1)[0] + "..."
        return f"Based on Araf's profile: {snippet}"


class OpenAIProvider(LLMProvider):
    def __init__(self, api_key: str, model: str = "gpt-4o-mini"):
        self.api_key = api_key
        self.model = model

    def generate(self, question: str, context_chunks: List[str]) -> str:
        try:
            r = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": "You are Araf's portfolio AI."},
                        {"role": "user", "content": _build_prompt(question, context_chunks)},
                    ],
                    "temperature": 0.3,
                },
                timeout=30,
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            log.exception("OpenAI call failed: %s", e)
            return MockLLMProvider().generate(question, context_chunks)


class AnthropicProvider(LLMProvider):
    def __init__(self, api_key: str, model: str = "claude-3-haiku-20240307"):
        self.api_key = api_key
        self.model = model

    def generate(self, question: str, context_chunks: List[str]) -> str:
        try:
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": self.model,
                    "max_tokens": 512,
                    "messages": [
                        {"role": "user", "content": _build_prompt(question, context_chunks)}
                    ],
                },
                timeout=30,
            )
            r.raise_for_status()
            return r.json()["content"][0]["text"].strip()
        except Exception as e:
            log.exception("Anthropic call failed: %s", e)
            return MockLLMProvider().generate(question, context_chunks)


class GeminiProvider(LLMProvider):
    def __init__(self, api_key: str, model: str = "gemini-1.5-flash"):
        self.api_key = api_key
        self.model = model

    def generate(self, question: str, context_chunks: List[str]) -> str:
        try:
            url = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{self.model}:generateContent?key={self.api_key}"
            )
            r = requests.post(
                url,
                json={
                    "contents": [
                        {"parts": [{"text": _build_prompt(question, context_chunks)}]}
                    ]
                },
                timeout=30,
            )
            r.raise_for_status()
            return r.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
        except Exception as e:
            log.exception("Gemini call failed: %s", e)
            return MockLLMProvider().generate(question, context_chunks)


class OllamaProvider(LLMProvider):
    def __init__(self, host: str, model: str = "llama3"):
        self.host = host
        self.model = model

    def generate(self, question: str, context_chunks: List[str]) -> str:
        try:
            r = requests.post(
                f"{self.host}/api/generate",
                json={
                    "model": self.model,
                    "prompt": _build_prompt(question, context_chunks),
                    "stream": False,
                },
                timeout=60,
            )
            r.raise_for_status()
            return r.json().get("response", "").strip()
        except Exception as e:
            log.exception("Ollama call failed: %s", e)
            return MockLLMProvider().generate(question, context_chunks)


def get_llm_provider() -> LLMProvider:
    """Factory: returns provider based on env config."""
    provider = os.getenv("LLM_PROVIDER", "mock").lower()
    if provider == "openai" and os.getenv("OPENAI_API_KEY"):
        return OpenAIProvider(os.getenv("OPENAI_API_KEY"))
    if provider == "anthropic" and os.getenv("ANTHROPIC_API_KEY"):
        return AnthropicProvider(os.getenv("ANTHROPIC_API_KEY"))
    if provider == "gemini" and os.getenv("GOOGLE_API_KEY"):
        return GeminiProvider(os.getenv("GOOGLE_API_KEY"))
    if provider == "ollama":
        return OllamaProvider(os.getenv("OLLAMA_HOST", "http://localhost:11434"))
    return MockLLMProvider()
