"""Lightweight RAG service using bag-of-words cosine similarity.

Zero external dependencies for embeddings — perfect for MVP.
Swap `_embed` for OpenAI/Voyage embeddings when scaling up.
"""
from __future__ import annotations
import logging
import math
import re
from collections import Counter
from typing import List, Tuple

from .knowledge_base import Chunk, load_knowledge_base

log = logging.getLogger(__name__)

_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")


def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN_RE.findall(text)]


def _embed(text: str) -> Counter:
    return Counter(_tokenize(text))


def _cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    common = set(a) & set(b)
    dot = sum(a[t] * b[t] for t in common)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


class RAGService:
    """In-memory retriever. Rebuild via `reindex()` after uploads."""

    def __init__(self, base_dir: str, extra_docs: List[str] | None = None):
        self.base_dir = base_dir
        self.extra_docs = extra_docs or []
        self.chunks: List[Chunk] = []
        self.vectors: List[Counter] = []
        self.reindex()

    def reindex(self) -> None:
        self.chunks = list(load_knowledge_base(self.base_dir))
        for i, d in enumerate(self.extra_docs):
            self.chunks.append(Chunk(source=f"db_seed_{i}", text=d))
        self.vectors = [_embed(c.text) for c in self.chunks]
        log.info("RAG reindexed: %d chunks.", len(self.chunks))

    def retrieve(self, query: str, top_k: int = 3) -> List[Tuple[Chunk, float]]:
        if not self.chunks:
            return []
        qv = _embed(query)
        scored = [
            (self.chunks[i], _cosine(qv, self.vectors[i]))
            for i in range(len(self.chunks))
        ]
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]
