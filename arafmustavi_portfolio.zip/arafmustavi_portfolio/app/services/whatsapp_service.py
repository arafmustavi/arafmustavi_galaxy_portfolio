"""WhatsApp helper: builds wa.me deep links with prefilled messages."""
from __future__ import annotations
from urllib.parse import quote


def build_whatsapp_url(number: str, message: str) -> str:
    """Return a wa.me URL. `number` must be international format without '+'."""
    clean = "".join(ch for ch in number if ch.isdigit())
    return f"https://wa.me/{clean}?text={quote(message)}"


def summarize_conversation(user_message: str, bot_reply: str | None = None) -> str:
    """Build a compact hand-off message for WhatsApp."""
    parts = [
        "Hi Araf, I was chatting with your website AI and would like to continue with you.",
        "",
        f"My question: {user_message}",
    ]
    if bot_reply:
        parts += ["", f"AI replied: {bot_reply}"]
    return "\n".join(parts)
