Drop profile/hero images here and reference them in templates.
