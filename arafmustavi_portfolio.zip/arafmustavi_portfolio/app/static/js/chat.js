(function(){
  const open = document.getElementById('chatOpen');
  const widget = document.getElementById('chatWidget');
  const close = document.getElementById('chatClose');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');
  const messages = document.getElementById('chatMessages');
  if(!open) return;

  let sid = sessionStorage.getItem('araf_sid');
  if(!sid){ sid = crypto.randomUUID(); sessionStorage.setItem('araf_sid', sid); }
  let lastReply = '';

  function render(kind, text, extra){
    const wrap = document.createElement('div');
    wrap.className = 'flex ' + (kind==='user' ? 'justify-end' : 'flex-col');
    if(kind==='user'){
      wrap.innerHTML = '<div class="chat-bubble-user"></div>';
      wrap.firstChild.textContent = text;
    } else if(kind==='bot'){
      wrap.innerHTML = '<div class="chat-bubble-bot"></div>';
      wrap.firstChild.textContent = text;
    } else if(kind==='escalate'){
      const div = document.createElement('div');
      div.className = 'chat-escalate';
      div.textContent = text;
      const a = document.createElement('a');
      a.href = extra.url; a.target='_blank';
      a.className = 'mt-2 inline-block bg-emerald-500 text-white px-3 py-1 rounded text-xs font-semibold';
      a.textContent = 'Continue on WhatsApp →';
      div.appendChild(document.createElement('br'));
      div.appendChild(a);
      wrap.appendChild(div);
    }
    messages.appendChild(wrap);
    messages.scrollTop = messages.scrollHeight;
  }

  open.addEventListener('click', ()=>{
    widget.classList.add('open');
    if(!messages.dataset.greeted){
      render('bot',"Hi! I'm Araf's AI assistant. Ask me about his work, projects, or services.");
      messages.dataset.greeted = '1';
    }
  });
  close.addEventListener('click', ()=> widget.classList.remove('open'));

  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const msg = input.value.trim();
    if(!msg) return;
    render('user', msg);
    input.value=''; input.disabled = true;
    const typing = document.createElement('div');
    typing.className='chat-bubble-bot'; typing.textContent='…';
    messages.appendChild(typing); messages.scrollTop = messages.scrollHeight;
    try{
      const r = await fetch('/api/chat', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({message: msg, session_id: sid})
      });
      const data = await r.json();
      typing.remove();
      render('bot', data.reply || '…');
      lastReply = data.reply || '';
      if(data.escalate && data.whatsapp_url){
        render('escalate', data.escalate_message || "I'd like Araf to answer this personally.", {url:data.whatsapp_url});
      }
    }catch(err){
      typing.remove();
      render('bot','Sorry, something went wrong.');
    }finally{
      input.disabled = false; input.focus();
    }
  });
})();
