(function(){
  const btn = document.getElementById('waButton');
  const bubble = document.getElementById('waBubble');
  if(!btn) return;
  const number = (btn.dataset.number||'').replace(/\D/g,'');
  const msg = encodeURIComponent(btn.dataset.message || 'Hi Araf!');
  btn.href = 'https://wa.me/' + number + '?text=' + msg;
  setTimeout(()=> bubble && bubble.classList.remove('hidden'), 3000);
  bubble && bubble.addEventListener('click', ()=> window.open(btn.href,'_blank'));
})();
