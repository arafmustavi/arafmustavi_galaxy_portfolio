# Knowledge Base

Drop `.pdf`, `.docx`, `.md`, or `.txt` files here — they'll be loaded into the
RAG index on next app start or via **Admin → Reindex Knowledge Base**.

Suggested initial files:
- `resume.pdf`
- `cv.pdf`
- `linkedin_export.pdf`
- `projects_detail.md`
