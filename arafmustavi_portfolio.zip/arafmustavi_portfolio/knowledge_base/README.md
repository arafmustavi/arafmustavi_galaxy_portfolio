# Knowledge Base

Drop any of the following file types here — they will be automatically
loaded into the RAG index the next time you (re)start the app or click
"Reindex Knowledge Base" in the admin dashboard.

Supported:
- `.pdf` (resume, CV, certificates, papers)
- `.docx`
- `.md` / `.markdown`
- `.txt`

Suggested initial files:
- `resume.pdf`
- `cv.pdf`
- `linkedin_export.pdf`
- `projects_detail.md`
- `services.md`
