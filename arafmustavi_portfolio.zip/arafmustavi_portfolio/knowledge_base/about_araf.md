# About Araf Mustavi

Araf Mustavi is a Global IT Business Analyst - SNO based in the APMEA region.
He specializes in AI, Retrieval-Augmented Generation (RAG), AR/VR training,
digital twins, and supply-chain digital transformation.

## Focus Areas
- Enterprise RAG systems
- Global AI operations chatbots (e.g. Atlas)
- AR consumer experiences (Modern Oral)
- VR training globalization
- Digital twins for factory operations
- Requirements engineering and stakeholder management

## Links
- LinkedIn: https://www.linkedin.com/in/arafmustavi/
- GitHub: https://github.com/arafmustavi
- Previous portfolio: https://arafmustavi.netlify.app/
