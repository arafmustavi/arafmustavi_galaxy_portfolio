# About Araf Mustavi

Araf Mustavi is a Global IT Business Analyst - SNO based in the APMEA region,
working at British American Tobacco. He specializes in AI, Retrieval-Augmented
Generation (RAG), AR/VR training, digital twins, and supply-chain digital
transformation. He is an experienced business analyst who bridges business
strategy and technical delivery.

## Focus Areas
- Enterprise Retrieval-Augmented Generation (RAG) systems
- Global AI operations chatbots (e.g., "Atlas")
- AR consumer experiences (Modern Oral)
- VR training globalization
- Digital twins for factory operations
- Requirements engineering and stakeholder management

## Contact
- LinkedIn: https://www.linkedin.com/in/arafmustavi/
- GitHub: https://github.com/arafmustavi
- Previous portfolio: https://arafmustavi.netlify.app/

## Services
Araf offers consulting on:
- Designing enterprise AI/RAG solutions
- Supply-chain digital transformation strategy
- AI training workshops and mentorship
- Business analysis for AI-first products
