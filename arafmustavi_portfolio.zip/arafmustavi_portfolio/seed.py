"""Seed default JSON content files if they don't exist. No database used."""
from __future__ import annotations
import json
import os

CONTENT_DIR = os.environ.get("CONTENT_DIR", "content")
os.makedirs(CONTENT_DIR, exist_ok=True)


DEFAULTS = {
    "profile.json": {
        "name": "Araf Mustavi",
        "title": "Global IT Business Analyst — Digital Transformation × AI × Supply Chain",
        "tagline": "I build AI, RAG, AR/VR and digital-twin solutions that transform how global supply-chain teams work.",
        "bio": (
            "I'm Araf Mustavi, a Global IT Business Analyst - SNO, focused on Supply Chain "
            "technology, AI, Machine Learning and Digital Transformation. I work across the "
            "APMEA region driving intelligent automation, AR/VR training globalization, "
            "digital twins, and Retrieval-Augmented Generation (RAG) solutions for enterprise "
            "supply-chain operations.\n\n"
            "I love turning ambiguous business problems into scalable, human-centered products."
        ),
        "location": "APMEA",
        "email": "",
        "linkedin": "https://www.linkedin.com/in/arafmustavi/",
        "github": "https://github.com/arafmustavi",
        "portfolio_url": "https://arafmustavi.netlify.app/",
    },
    "experience.json": [
        {
            "id": 1,
            "role": "Global IT Business Analyst - SNO",
            "company": "British American Tobacco",
            "location": "APMEA",
            "period": "2021 - Present",
            "order": 10,
            "description": (
                "Lead AI, RAG, AR/VR and digital-transformation initiatives across APMEA "
                "supply-chain operations. Bridge business strategy, technology delivery, "
                "and stakeholder management."
            ),
        },
        {
            "id": 2,
            "role": "IT Business Analyst",
            "company": "Previous Role",
            "location": "Bangladesh",
            "period": "2019 - 2021",
            "order": 5,
            "description": "Requirements engineering and process automation for enterprise systems.",
        },
    ],
    "projects.json": [
        {
            "id": 1, "title": "Global AI Ops Chatbot (Atlas)", "year": "2024", "featured": True,
            "summary": "Enterprise RAG chatbot for global supply-chain operations Q&A and SOP retrieval.",
            "description": ("Retrieval-Augmented Generation assistant serving APMEA operations teams. "
                            "Built on Azure OpenAI + vector search, integrates with SharePoint and internal APIs."),
            "tech_stack": "Python, LangChain, Azure OpenAI, pgvector, FastAPI",
            "url": "", "github_url": "",
        },
        {
            "id": 2, "title": "VR Training Globalization", "year": "2023", "featured": True,
            "summary": "Rolled out VR-based training across APMEA factories for standardized skill transfer.",
            "description": "Program managed content localization, headset logistics, and analytics pipeline.",
            "tech_stack": "Unity, Oculus, PowerBI, SharePoint",
            "url": "", "github_url": "",
        },
        {
            "id": 3, "title": "AR Modern Oral Consumer Experience", "year": "2023", "featured": True,
            "summary": "Augmented Reality consumer product discovery experience for retail.",
            "description": "AR overlays with product story-telling; A/B tested engagement metrics.",
            "tech_stack": "ARKit, ARCore, Unity",
            "url": "", "github_url": "",
        },
        {
            "id": 4, "title": "Digital Twin - Factory Ops", "year": "2024", "featured": False,
            "summary": "Live digital twin of production line for scenario simulation.",
            "description": "",
            "tech_stack": "Azure Digital Twins, IoT Hub, Power BI",
            "url": "", "github_url": "",
        },
        {
            "id": 5, "title": "Stock Build Note Digitization", "year": "2022", "featured": False,
            "summary": "Replaced paper-based stock build notes with mobile-first digital workflow.",
            "description": "",
            "tech_stack": "Power Apps, Power Automate, SQL",
            "url": "", "github_url": "",
        },
        {
            "id": 6, "title": "Vietnam Factory Portal", "year": "2022", "featured": False,
            "summary": "Unified internal portal serving Vietnam factory operations and analytics.",
            "description": "",
            "tech_stack": "SharePoint, Power BI, .NET",
            "url": "", "github_url": "",
        },
    ],
    "certifications.json": [
        {"id": 1, "title": "Microsoft Agentic AI Business Solutions Architect", "issuer": "Microsoft", "year": "2025", "url": ""},
        {"id": 2, "title": "Microsoft Power BI Data Analyst Associate (PL-300)", "issuer": "Microsoft", "year": "2023", "url": ""},
        {"id": 3, "title": "Microsoft Power Platform Fundamentals (PL-900)", "issuer": "Microsoft", "year": "2022", "url": ""},
    ],
    "publications.json": [],
    "courses.json": [],
    "blog.json": [
        {
            "id": 1,
            "title": "Why RAG Beats Fine-Tuning for Enterprise Ops",
            "slug": "rag-vs-finetuning-enterprise",
            "excerpt": "A pragmatic look at when RAG wins over fine-tuning in supply-chain operations.",
            "content": "Long-form post coming soon.",
            "published_at": "2025-06-15T10:00:00Z",
        },
        {
            "id": 2,
            "title": "Digital Twins on the Factory Floor",
            "slug": "digital-twins-factory-floor",
            "excerpt": "Lessons learned deploying digital twins in a production environment.",
            "content": "Long-form post coming soon.",
            "published_at": "2025-05-01T10:00:00Z",
        },
    ],
    "faqs.json": [
        {"id": 1, "question": "Who is Araf?", "answer": "Araf Mustavi is a Global IT Business Analyst focused on AI, RAG, AR/VR, and digital transformation for supply-chain."},
        {"id": 2, "question": "What does he do?", "answer": "He designs and delivers enterprise AI and digital solutions—chatbots, digital twins, VR training, AR consumer experiences."},
        {"id": 3, "question": "Can he provide consulting?", "answer": "Yes. Araf is available for consulting on AI/RAG solutions, supply-chain digitization, and requirements engineering."},
        {"id": 4, "question": "Can I hire him for training or workshops?", "answer": "Yes—reach out via WhatsApp or LinkedIn to discuss custom training on AI, RAG, or business analysis."},
        {"id": 5, "question": "Where is he based?", "answer": "APMEA region. He works with global teams across multiple time zones."},
        {"id": 6, "question": "What technologies does he work with?", "answer": "Python, LangChain, Azure OpenAI, FastAPI/Flask, Power BI, Power Platform, Unity/AR, pgvector/Qdrant, SQL."},
        {"id": 7, "question": "How can I schedule a meeting?", "answer": "Please message Araf on WhatsApp—the assistant will hand you over automatically."},
    ],
}


def main():
    created, skipped = [], []
    for fname, data in DEFAULTS.items():
        path = os.path.join(CONTENT_DIR, fname)
        if os.path.exists(path):
            skipped.append(fname)
            continue
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        created.append(fname)
    print(f"Content dir: {CONTENT_DIR}")
    print(f"Created ({len(created)}): {created}")
    print(f"Skipped ({len(skipped)}): {skipped}")


if __name__ == "__main__":
    main()
