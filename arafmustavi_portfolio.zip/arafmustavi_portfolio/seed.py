"""Seed script - populates DB with Araf Mustavi's baseline profile info."""
from __future__ import annotations
import os
from werkzeug.security import generate_password_hash
from app import create_app
from app.extensions import db
from app.models.models import (
    AdminUser, Project, Certification, Experience, BlogPost, Course, Publication, FAQ
)

app = create_app()

PROJECTS = [
    dict(title="Global AI Ops Chatbot (Atlas)", year="2024",
         summary="Enterprise RAG chatbot for global supply-chain operations Q&A and SOP retrieval.",
         description="Retrieval-Augmented Generation assistant serving APMEA operations teams. "
                     "Built on Azure OpenAI + vector search, integrates with SharePoint and internal APIs.",
         tech_stack="Python, LangChain, Azure OpenAI, pgvector, FastAPI",
         featured=True),
    dict(title="VR Training Globalization", year="2023",
         summary="Rolled out VR-based training across APMEA factories for standardized skill transfer.",
         description="Program managed content localization, headset logistics, and analytics pipeline.",
         tech_stack="Unity, Oculus, PowerBI, SharePoint",
         featured=True),
    dict(title="AR Modern Oral Consumer Experience", year="2023",
         summary="Augmented Reality consumer product discovery experience for retail.",
         description="AR overlays with product story-telling; A/B tested engagement metrics.",
         tech_stack="ARKit, ARCore, Unity",
         featured=True),
    dict(title="Digital Twin - Factory Ops", year="2024",
         summary="Live digital twin of production line for scenario simulation.",
         tech_stack="Azure Digital Twins, IoT Hub, Power BI"),
    dict(title="Stock Build Note Digitization", year="2022",
         summary="Replaced paper-based stock build notes with mobile-first digital workflow.",
         tech_stack="Power Apps, Power Automate, SQL"),
    dict(title="Vietnam Factory Portal", year="2022",
         summary="Unified internal portal serving Vietnam factory operations and analytics.",
         tech_stack="SharePoint, Power BI, .NET"),
]

CERTS = [
    dict(title="Microsoft Agentic AI Business Solutions Architect", issuer="Microsoft", year="2025"),
    dict(title="Microsoft Power BI Data Analyst Associate (PL-300)", issuer="Microsoft", year="2023"),
    dict(title="Microsoft Power Platform Fundamentals (PL-900)", issuer="Microsoft", year="2022"),
]

EXPERIENCES = [
    dict(role="Global IT Business Analyst - SNO", company="British American Tobacco",
         location="APMEA", period="2021 - Present", order=10,
         description="Lead AI, RAG, AR/VR and digital-transformation initiatives across APMEA supply-chain operations. "
                     "Bridge business strategy, technology delivery, and stakeholder management."),
    dict(role="IT Business Analyst", company="Previous Role",
         location="Bangladesh", period="2019 - 2021", order=5,
         description="Requirements engineering and process automation for enterprise systems."),
]

FAQS = [
    ("Who is Araf?",
     "Araf Mustavi is a Global IT Business Analyst focused on AI, RAG, AR/VR, and digital transformation for supply-chain."),
    ("What does he do?",
     "He designs and delivers enterprise AI and digital solutions—chatbots, digital twins, VR training, AR consumer experiences."),
    ("Can he provide consulting?",
     "Yes. Araf is available for consulting on AI/RAG solutions, supply-chain digitization, and requirements engineering."),
    ("Can I hire him for training or workshops?",
     "Yes—reach out via WhatsApp or LinkedIn to discuss custom training on AI, RAG, or business analysis."),
    ("Where is he based?",
     "APMEA region. He works with global teams across multiple time zones."),
    ("What technologies does he work with?",
     "Python, LangChain, Azure OpenAI, FastAPI/Flask, Power BI, Power Platform, Unity/AR, pgvector/Qdrant, SQL."),
    ("How can I schedule a meeting?",
     "Please message Araf on WhatsApp—the assistant will hand you over automatically."),
]

BLOGS = [
    dict(title="Why RAG Beats Fine-Tuning for Enterprise Ops",
         slug="rag-vs-finetuning-enterprise",
         excerpt="A pragmatic look at when RAG wins over fine-tuning in supply-chain operations.",
         content="Long-form post coming soon."),
    dict(title="Digital Twins on the Factory Floor",
         slug="digital-twins-factory-floor",
         excerpt="Lessons learned deploying digital twins in a production environment.",
         content="Long-form post coming soon."),
]

with app.app_context():
    db.create_all()

    if AdminUser.query.count() == 0:
        username = os.getenv("ADMIN_USERNAME", "araf")
        pw_hash = os.getenv("ADMIN_PASSWORD_HASH") or generate_password_hash("changeme")
        db.session.add(AdminUser(username=username, password_hash=pw_hash))
        print(f"Created admin user: {username} (default password: changeme if you did not set ADMIN_PASSWORD_HASH)")

    if Project.query.count() == 0:
        for p in PROJECTS: db.session.add(Project(**p))
    if Certification.query.count() == 0:
        for c in CERTS: db.session.add(Certification(**c))
    if Experience.query.count() == 0:
        for e in EXPERIENCES: db.session.add(Experience(**e))
    if FAQ.query.count() == 0:
        for q, a in FAQS: db.session.add(FAQ(question=q, answer=a))
    if BlogPost.query.count() == 0:
        for b in BLOGS: db.session.add(BlogPost(**b))

    db.session.commit()
    print("Seed complete.")
