"""RAG service tests."""
from app.services.rag_service import RAGService

def test_rag_retrieves_from_seed_docs(tmp_path):
    rag = RAGService(base_dir=str(tmp_path), extra_docs=[
        "Araf built an AI chatbot named Atlas for global supply-chain operations.",
        "He works on digital twin and AR/VR training programs.",
    ])
    hits = rag.retrieve("AI chatbot Atlas")
    assert hits
    assert hits[0][1] > 0
