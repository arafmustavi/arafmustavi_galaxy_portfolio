"""Route smoke tests."""
import pytest
from app import create_app
from app.extensions import db

@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///:memory:"
    with app.app_context():
        db.create_all()
    return app.test_client()

def test_index(client):
    assert client.get("/").status_code == 200

def test_about(client):
    assert client.get("/about").status_code == 200

def test_healthz(client):
    r = client.get("/healthz")
    assert r.status_code == 200
    assert r.json["status"] == "ok"

def test_chat(client):
    r = client.post("/api/chat", json={"message": "Who is Araf?"})
    assert r.status_code == 200
    assert "reply" in r.json
