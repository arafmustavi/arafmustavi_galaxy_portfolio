"""Route smoke tests — file-based, no DB."""
import os
import json
import tempfile
import pytest


@pytest.fixture
def client(tmp_path, monkeypatch):
    # Isolated content dir per test
    content_dir = tmp_path / "content"
    content_dir.mkdir()
    (content_dir / "profile.json").write_text(json.dumps({
        "name": "Araf Mustavi", "title": "Test", "tagline": "t", "bio": "b",
        "linkedin": "x", "github": "y", "portfolio_url": "z"
    }))
    for name in ["experience", "projects", "certifications", "publications",
                 "courses", "blog", "faqs"]:
        (content_dir / f"{name}.json").write_text("[]")

    monkeypatch.setenv("CONTENT_DIR", str(content_dir))
    monkeypatch.setenv("KNOWLEDGE_BASE_DIR", str(tmp_path / "kb"))

    from app import create_app
    app = create_app()
    app.config["TESTING"] = True
    return app.test_client()


def test_index(client):     assert client.get("/").status_code == 200
def test_about(client):     assert client.get("/about").status_code == 200
def test_projects(client):  assert client.get("/projects").status_code == 200
def test_contact(client):   assert client.get("/contact").status_code == 200
def test_healthz(client):
    r = client.get("/healthz")
    assert r.status_code == 200
    assert r.json["status"] == "ok"


def test_chat(client):
    r = client.post("/api/chat", json={"message": "Who is Araf?"})
    assert r.status_code == 200
    assert "reply" in r.json
